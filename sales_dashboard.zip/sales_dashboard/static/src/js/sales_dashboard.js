odoo.define('sales_dashboard.dashboard_action', function (require){
    'use strict';
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var QWeb = core.qweb;
    var rpc = require('web.rpc');
    var ajax = require('web.ajax');
    var SalesDashBoard = AbstractAction.extend({
        template: 'SalesDashboard',
        init: function(parent, context) {
           this._super(parent, context);
        },
        events :{
            'change #data_filter': 'fetch_data'
        },
        start: function() {
            var self = this;
            this.set("title", 'Dashboard');
            return this._super().then(function() {
                self.render_dashboards()
            });
        },
        date:0,
        data_filter:0,
        fetch_data: function(){
            this.data_filter = $('#data_filter').val()
            this.chart_by_team.destroy()
            this.chart_by_member.destroy()
            this.chart_customer.destroy()
            this.order_status.destroy()
            this.invoice_status.destroy()
            this.render_dashboards()
        },
        render_dashboards: function(){
            var self = this
             rpc.query({
                route: `/sale_dashboard/0/${self.data_filter}`,
                params: {}
            }).then(function(res){
                var data = res['data']
                var datas = [res['total_quotation'],res['total_sales'],res['invoiced_amount']]
                var datasets = []
                $('#title-01').text(res['total_quotation']);
                $('#title-02').text(res['total_sales']);
                $('#title-03').text(res['invoiced_amount']);
                var count = 1
                $('#by-team').html('')
                data.forEach(element => {
                    $('#by-team').append(`
                    <tr>
                        <th scope="row">${count}</th>
                        <td>${element['name']}</td>
                        <td>${element['leader']}</td>
                        <td>${element['target']}</td>
                     </tr>
                    `);
                    datasets.push({
                        label : element['name'],
                        backgroundColor: self.chart_color[count-1],
                        borderColor: self.chart_color[count-1],
                        data: [element['quotations'],element['sales'],element['invoiced']]
                    })
                    count += 1
                });
                self.load_chart_by_team(datas,datasets)
            })
            rpc.query({
                route: `/sale_dashboard/1/${self.data_filter}`,
                params: {}
            }).then(function(res){
                var data = res['data']
                var datas = [res['total_quotation'],res['total_sales'],res['invoiced_amount']]
                var datasets = []
                var count = 1
                $('#by-member').html('')
                data.forEach(element => {
                    $('#by-member').append(`
                    <tr>
                        <th scope="row">${count}</th>
                        <td>${element['name']}</td>
                        <td>${element['team']}</td>
                        <td>${element['leader']}</td>
                     </tr>
                    `);
                    count += 1
                    datasets.push({
                        label : element['name'],
                        backgroundColor: self.chart_color[count-1],
                        borderColor: self.chart_color[count-1],
                        data: [element['quotations'],element['sales'],element['invoiced']]
                    })
                });
                self.load_chart_by_member(datas,datasets)
            })
            rpc.query({
                route: `/sale_dashboard/2/${self.data_filter}`,
                params: {}
            }).then(function(res){
                var data = res['data']
                var datas = []
                var label = []
                var count = 1
                $('#top-customer').html('')
                data.forEach(element => {
                    $('#top-customer').append(`
                    <tr>
                        <th scope="row">${count}</th>
                        <td>${element['name']}</td>
                        <td>${element['email']}</td>
                        <td>${element['quotations']+ element['sales']}</td>
                     </tr>
                    `);
                    count += 1
                    label.push(element['name'])
                    datas.push(element['quotations']+ element['sales'])
                })
                    self.load_chart_customer(label,datas)
            });
            rpc.query({
                route: `/sale_dashboard/3/${self.data_filter}`,
                params: {}
            }).then(function(res){
                var count = 1
                $('#highest-selling').html('')
                res['highest'].forEach(element => {
                    $('#highest-selling').append(`
                        <tr>
                            <th scope="row">${count}</th>
                            <td>${element['name']}</td>
                            <td>${element['rp']}</td>
                        </tr>
                    `)
                    count += 1
                });
                count = 1
                $('#lowest-product').html('')
                res['lowest'].forEach(element => {
                    $('#lowest-product').append(`
                        <tr>
                            <th scope="row">${count}</th>
                            <td>${element['name']}</td>
                            <td>${element['rp']}</td>
                        </tr>
                    `)
                    count += 1
                });
            });
            rpc.query({
                route: `/sale_dashboard/4/${self.data_filter}`,
                params: {}
            }).then(function(res){
                var order_status_label = res['order_status']
                var order_amount = res['order_status_amount']
                var invoice_status_label = res['invoice_status']
                var invoice_amount = res['invoice_status_amount']
                self.chart_order_status(order_status_label,order_amount)
                self.chart_invoice_status(invoice_status_label,invoice_amount)
            })

        },
        chart_color: ['#FF6384','#59CE8F','#9C9EFE','#FF6722','#4E91FF'],
        chart_by_team: '',
        chart_by_member:'',
        chart_customer:'',
        order_status:'',
        invoice_status:'',
        load_chart_by_team: function(datas,datasets){
            var data = {
               labels: ['quotations','sales','invoiced'],
               datasets:datasets
            };
            var config = {
                type: 'bar',
                data: data,
                options: {}
            };
            this.chart_by_team = new Chart(
                document.getElementById('by-team-chart'),
                config
            );
        },
        load_chart_by_member: function(datas,datasets){
            var data = {
               labels: ['quotations','sales','invoiced'],
               datasets: datasets
            };
            var config = {
                type: 'bar',
                data: data,
                options: {}
            };
            this.chart_by_member = new Chart(
                document.getElementById('by-member-chart'),
                config
            );
        },
        load_chart_customer: function(label,datas){
            var data = {
              labels: label,
              datasets: [
                {
                  label: 'Top 10 Customers',
                  data: datas,
                  backgroundColor: this.chart_color[Math.floor(Math.random()*this.chart_color.length)],
                  borderColor: this.chart_color[Math.floor(Math.random()*this.chart_color.length)],
                }
              ]
            };
            var config = {
                type: 'bar',
                data: data,
                options: {},
            };
            this.chart_customer = new Chart(
                document.getElementById('top-customer-chart'),
                config
            );
        },
        chart_order_status: function(label,datas){
            var data = {
              labels: label,
              datasets: [
                {
                  label: 'Order Status',
                  data: datas,
                  backgroundColor: this.chart_color[Math.floor(Math.random()*this.chart_color.length)],
                  borderColor: this.chart_color[Math.floor(Math.random()*this.chart_color.length)],
                }
              ]
            };
            var config = {
                type: 'bar',
                data: data,
                options: {},
            };
            this.order_status = new Chart(
                document.getElementById('order-status-chart'),
                config
            );
        },
        chart_invoice_status: function(label,datas){
            var data = {
              labels: label,
              datasets: [
                {
                  label: 'Invoice Status',
                  data: datas,
                  backgroundColor: this.chart_color[Math.floor(Math.random()*this.chart_color.length)],
                  borderColor: this.chart_color[Math.floor(Math.random()*this.chart_color.length)],
                }
              ]
            };
            var config = {
                type: 'bar',
                data: data,
                options: {},
            };
            this.invoice_status = new Chart(
                document.getElementById('invoice-status-chart'),
                config
            );
        }
    })
    core.action_registry.add('sale_dashboard_tags', SalesDashBoard);
    return SalesDashBoard;
})
