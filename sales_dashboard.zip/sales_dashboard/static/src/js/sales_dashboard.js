odoo.define('sales_dashboard.dashboard_action', function (require){
    'use strict';
    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var QWeb = core.qweb;
    var rpc = require('web.rpc');
    var ajax = require('web.ajax');
    var SalesDashBoard = AbstractAction.extend({
        template: 'SalesDashboard',
        init: function(parent, context) {
           this._super(parent, context);
        },
        events :{
            'change #data_filter': 'fech_data',
        },
        start: function() {
            var self = this;
            this.set("title", 'Dashboard');
            return this._super().then(function() {
                self.render_dashboards()
            });
        },
        sale_oders:[],
        order_by_team :[],
        sales_by_memeber:[],
        filter_id:0,
        data_id:0,
        render_dashboards: function(){
            var self = this
            $('#container-wrapper').html('')
            rpc.query({
                route: `/sale_dashboard/${this.filter_id}`,
                params: {}
                }).then(function(res){
                    var id_counter = 0
                    var data = res['data']
                    var totals = res['totals']
                    var labels = []
                    data.forEach(element => {
                        $('#container-wrapper').html($('#container-wrapper').html() +`
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="heading${id_counter}">
                            <button class="accordion-button" data-id=${id_counter} type="button" data-bs-toggle="collapse" data-bs-target="#collapse${id_counter}" aria-expanded="true" aria-controls="collapse${id_counter}">
                                ${element['name']}
                            </button>
                            </h2>
                            <div id="collapse${id_counter}" class="accordion-collapse collapse" aria-labelledby="heading${id_counter}" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="card text-center" id="container-wrapper" >
                                    <div class="card-header">
                                    <ul class="nav nav-tabs card-header-tabs">
                                        <li class="nav-item">
                                        <a class="nav-link active" aria-current="true" id="nav-hed" href="#">Quotations</a>
                                        </li>
                                    </ul>
                                    </div>
                                    <div class="card-body">
                                    <div class="container" id="table-container">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">customer</th>
                                                    <th scope="col">State</th>
                                                    <th scope="col">Invoice Status</th>
                                                    <th scope="col">Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbody-${id_counter}">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            </div>
                            </div>
                        </div>
                        `);
                    labels.push(element['name'])
                    id_counter += 1
                    })
                    $('#title-01').text('$'+res['total_quotation']);
                    $('#title-02').text('$'+res['total_sales']);
                    $('#title-03').text('$'+res['invoiced_amount']);
                    self.load_chart(totals,labels)
                    $('.accordion-button').click(function (e) {
                        var this_id = $(this).data('id')
                        $('#title-01').text('$'+data[this_id]['quotations']);
                        $('#title-02').text('$'+data[this_id]['sales']);
                        $('#title-03').text('$'+data[this_id]['invoiced']);
                        var orders = data[this_id]['data']
                        var counter = 1
                        orders.forEach(element => {
                            $(`#tbody-${this_id}`).append(`
                            <tr>
                                <th scope="row">${counter}</th>
                                <td><a href="/web#id=${element['id']}&menu_id=178&cids=1&action=296&model=sale.order&view_type=form">${element['name']}</a></td>
                                <td>${element['state']}</td>
                                <td>${element['customer']}</td>
                                <td>${element['state']}</td>
                                <td>${element['invoice_status']}</td>
                                <td>$${element['total']}</td>
                            </tr>
                        `);
                        counter += 1
                        });
                    });
                });
        },
        fech_data: function(){
            this.filter_id = $('#data_filter').val()
            this.render_dashboards()
        },
        load_chart: function(totals,labels){
            var datas = []
            var count = 0
            labels.forEach(element => {
                datas.push({
                    label : element,
                    backgroundColor: `rgb(${255-count}, ${99+count}, ${132+count})`,
                    borderColor: `rgb(${255-count}, ${99+count}, ${132+count})`,
                    data: totals[count]
                })
                count +=1
            });
            console.log(datas)
            var data = {
               labels:['quataion', 'sale order'],
               datasets: datas
            };
            const config = {
                type: 'bar',
                data: data,
                options: {}
            };
            const myChart = new Chart(
                document.getElementById('myChart'),
                config
            );
        }
    })
    core.action_registry.add('sale_dashboard_tags', SalesDashBoard);
    return SalesDashBoard;
})

