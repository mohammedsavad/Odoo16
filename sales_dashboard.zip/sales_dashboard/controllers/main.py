from odoo import http
from odoo.http import request


class FilterController(http.Controller):

    @http.route('/sale_dashboard/<int:filter_id>/<int:date_id>', csrf=False, type='json')
    def filter(self, filter_id, date_id):
        context = {}
        inner_context = []
        if filter_id == 0:
            teams = request.env['crm.team'].search([])
            for team in teams:
                if date_id == 0:
                    query = f"""
                        SELECT amount_total,state,invoice_status,name 
                        FROM sale_order 
                        WHERE team_id = '{team.id}'
                        """
                elif date_id == 1:
                    query = f"""
                        SELECT amount_total,state,invoice_status,name 
                        FROM sale_order 
                        WHERE team_id = '{team.id}'
                        AND Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                        AND Extract(Week FROM create_date) = Extract(Week FROM DATE(NOW())) 
                        AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                            """
                else:
                    query = f"""
                       SELECT amount_total,state,invoice_status,name 
                       FROM sale_order 
                       WHERE team_id = '{team.id}'
                       AND Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                       AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                       """
                request.env.cr.execute(query)
                order_data = request.env.cr.fetchall()
                to_chart = self.fech_data_condition(order_data)
                data = {
                    'id': team.id,
                    'name': team.name,
                    'leader': team.user_id.partner_id.name,
                    'target': team.invoiced_target,
                    'quotations': to_chart[0],
                    'sales': to_chart[1],
                    'invoiced': to_chart[2]
                }
                inner_context.append(data)

        elif filter_id == 1:
            team_members = request.env['crm.team.member'].search([])
            for member in team_members:
                if date_id == 0:
                    query = f"""
                        SELECT amount_total,state,invoice_status,name 
                        FROM sale_order 
                        WHERE user_id = '{member.user_id.id}'
                        """
                elif date_id == 1:
                    query = f"""
                        SELECT amount_total,state,invoice_status,name 
                        FROM sale_order 
                        WHERE user_id = '{member.user_id.id}'
                        AND Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                        AND Extract(Week FROM create_date) = Extract(Week FROM DATE(NOW())) 
                        AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                        """
                else:
                    query = f"""
                       SELECT amount_total,state,invoice_status,name 
                       FROM sale_order 
                       WHERE user_id = '{member.user_id.id}'
                       AND Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                       AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                       """
                request.env.cr.execute(query)
                order_data = request.env.cr.fetchall()
                to_chart = self.fech_data_condition(order_data)
                data = {
                    'id': member.id,
                    'name': member.user_id.partner_id.name,
                    'team': member.crm_team_id.name,
                    'leader': member.crm_team_id.user_id.partner_id.name,
                    'quotations': to_chart[0],
                    'sales': to_chart[1],
                    'invoiced': to_chart[2]
                }
                inner_context.append(data)
        elif filter_id == 2:
            query = """
               SELECT partner_id, COUNT(partner_id) as rep_count
               FROM sale_order GROUP BY partner_id 
               order by rep_count desc  limit 10 """
            request.env.cr.execute(query)
            data = request.env.cr.dictfetchall()
            for rec in data:
                if date_id == 0:
                    query = f"""
                        SELECT sl.amount_total,sl.state,sl.invoice_status,sl.name,
                        pr.id, pr.name as partner, pr.email
                        FROM sale_order sl
                        JOIN res_partner pr 
                        on sl.partner_id = pr.id
                        where sl.partner_id = {rec['partner_id']}
                        """
                elif date_id == 1:
                    query = f"""
                        SELECT sl.amount_total,sl.state,sl.invoice_status,sl.name,
                        pr.id, pr.name as partner, pr.email
                        FROM sale_order sl
                        JOIN res_partner pr 
                        on sl.partner_id = pr.id
                        where sl.partner_id = {rec['partner_id']}
                        AND Extract(MONTH FROM sl.date_order) = Extract(MONTH FROM DATE(NOW()))
                        AND Extract(Week FROM sl.date_order) = Extract(Week FROM DATE(NOW())) 
                        AND Extract(Year FROM sl.date_order) = Extract(Year FROM DATE(NOW()))
                        """
                else:
                    query = f"""
                        SELECT sl.amount_total,sl.state,sl.invoice_status,sl.name,
                        pr.id, pr.name as partner, pr.email
                        FROM sale_order sl
                        JOIN res_partner pr 
                        on sl.partner_id = pr.id
                        where sl.partner_id = {rec['partner_id']}
                        AND Extract(MONTH FROM sl.date_order) = Extract(MONTH FROM DATE(NOW()))
                        AND Extract(Year FROM sl.date_order) = Extract(Year FROM DATE(NOW()))
                        """
                request.env.cr.execute(query)
                order_data = request.env.cr.fetchall()
                to_chart = self.fech_data_condition(order_data)
                data = {
                    'id': rec['partner_id'],
                    'name': to_chart[3],
                    'email': to_chart[4],
                    'quotations': to_chart[0],
                    'sales': to_chart[1],
                    'invoiced': to_chart[2]
                }
                inner_context.append(data)
        elif filter_id == 3:
            if date_id == 0:
                query = """
                    SELECT product_id , sum(product_uom_qty) as rp
                    FROM sale_order_line GROUP BY product_id 
                    order by rp  limit 10;
                   """
                query_ = """
                   SELECT product_id , sum(product_uom_qty) as rp
                    FROM sale_order_line GROUP BY product_id 
                    order by rp desc  limit 10;
                   """
            elif date_id == 1:
                query = """
                    SELECT product_id , sum(product_uom_qty) as rp
                    FROM sale_order_line
                    WHERE Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                    AND Extract(Week FROM create_date) = Extract(Week FROM DATE(NOW())) 
                    AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                    GROUP BY product_id 
                    order by rp limit 10;
                  """
                query_ = """
                    SELECT product_id , sum(product_uom_qty) as rp
                    FROM sale_order_line
                    WHERE Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                    AND Extract(Week FROM create_date) = Extract(Week FROM DATE(NOW())) 
                    AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                    GROUP BY product_id 
                    order by rp desc  limit 10;
                  """
            else:
                query = """
                    SELECT product_id , sum(product_uom_qty) as rp
                    FROM sale_order_line
                    WHERE Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                    AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                    GROUP BY product_id 
                    order by rp limit 10;
                    """
                query_ = """
                    SELECT product_id , sum(product_uom_qty) as rp
                    FROM sale_order_line
                    WHERE Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                    AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                    GROUP BY product_id 
                    order by rp desc  limit 10;
                    """
            request.env.cr.execute(query_)
            data = request.env.cr.dictfetchall()
            for rec in data:
                product_id = request.env['product.product'].search([
                    ('id', '=', rec['product_id'])
                ])
                rec['name'] = product_id.product_tmpl_id.name
                inner_context.append(rec)
            context['highest'] = inner_context
            inner_context = []
            request.env.cr.execute(query)
            data = request.env.cr.dictfetchall()
            for rec in data:
                product_id = request.env['product.product'].search([
                    ('id', '=', rec['product_id'])
                ])
                rec['name'] = product_id.product_tmpl_id.name
                inner_context.append(rec)
            context['lowest'] = inner_context
            return context
        elif filter_id == 4:
            order_status = ['draft', 'sent', 'sale']
            amount_total = []
            for item in order_status:
                if date_id == 0:
                    query = f"""
                        SELECT sum(amount_total)
                        FROM sale_order 
                        WHERE state = '{item}'
                       """
                elif date_id == 1:
                    query = f"""
                        SELECT sum(amount_total)
                        FROM sale_order 
                        WHERE state = '{item}'
                        AND Extract(MONTH FROM date_order) = Extract(MONTH FROM DATE(NOW()))
                        AND Extract(Week FROM date_order) = Extract(Week FROM DATE(NOW())) 
                        AND Extract(Year FROM date_order) = Extract(Year FROM DATE(NOW()))
                       """
                else:
                    query = f"""
                        SELECT sum(amount_total)
                        FROM sale_order 
                        WHERE state = '{item}'
                        AND Extract(MONTH FROM date_order) = Extract(MONTH FROM DATE(NOW()))
                        AND Extract(Year FROM date_order) = Extract(Year FROM DATE(NOW()))
                       """
                request.env.cr.execute(query)
                order_data = request.env.cr.fetchall()
                amount_total.append(order_data[0][0])
            context['order_status_amount'] = amount_total
            context['order_status'] = order_status
            amount_total = []
            invoice_status = ['upselling', 'invoiced', 'to invoice', 'no']
            for item in invoice_status:
                if date_id == 0:
                    query = f"""
                        SELECT sum(amount_total)
                        FROM sale_order 
                        WHERE invoice_status = '{item}'
                        """
                elif date_id == 1:
                    query = f"""
                        SELECT sum(amount_total)
                        FROM sale_order 
                        WHERE invoice_status = '{item}'
                        AND Extract(MONTH FROM date_order) = Extract(MONTH FROM DATE(NOW()))
                        AND Extract(Week FROM date_order) = Extract(Week FROM DATE(NOW())) 
                        AND Extract(Year FROM date_order) = Extract(Year FROM DATE(NOW()))
                        """
                else:
                    query = f"""
                        SELECT sum(amount_total)
                        FROM sale_order 
                        WHERE invoice_status = '{item}'
                        AND Extract(MONTH FROM date_order) = Extract(MONTH FROM DATE(NOW()))
                        AND Extract(Year FROM date_order) = Extract(Year FROM DATE(NOW()))
                        """
                request.env.cr.execute(query)
                order_data = request.env.cr.fetchall()
                amount_total.append(order_data[0][0])
            context['invoice_status'] = invoice_status
            context['invoice_status_amount'] = amount_total
            return context
        fetched_data = self.fetch_order_data(date_id)
        context = {
            'total_quotation': fetched_data[0],
            'total_sales': fetched_data[1],
            'invoiced_amount': fetched_data[2],
            'data': inner_context,
            'filter_id': filter_id,
        }
        return context

    def fech_data_condition(self, order_data):
        partner_name = ''
        partner_email = ''
        quotations = 0
        sales = 0
        invoiced = 0
        for order in order_data:
            try:
                partner_name = order[5]
                partner_email = order[6]
            except IndexError:
                pass
            if order[1] == 'draft':
                quotations += order[0]
            elif order[1] == 'send':
                quotations += order[0]
            elif order[1] == 'sale':
                sales += order[0]
            if order[2] == 'invoiced':
                invoiced += order[0]
        return [quotations, sales, invoiced, partner_name, partner_email]

    def fetch_order_data(self, date_id):
        total_quotation = 0
        total_sales = 0
        invoiced_amount = 0
        if date_id == 0:
            query = f"""
                SELECT amount_total,state,invoice_status,name 
                FROM sale_order 
                """
        elif date_id == 1:
            query = f"""
                SELECT amount_total,state,invoice_status,name 
                FROM sale_order 
                WHERE Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
                AND Extract(Week FROM create_date) = Extract(Week FROM DATE(NOW())) 
                AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
                """
        else:
            query = f"""
               SELECT amount_total,state,invoice_status,name 
               FROM sale_order 
               WHERE Extract(MONTH FROM create_date) = Extract(MONTH FROM DATE(NOW()))
               AND Extract(Year FROM create_date) = Extract(Year FROM DATE(NOW()))
               """
        request.env.cr.execute(query)
        order_data = request.env.cr.fetchall()
        for order in order_data:
            if order[1] == 'draft':
                total_quotation += order[0]
            elif order[1] == 'send':
                total_quotation += order[0]
            elif order[1] == 'sale':
                total_sales += order[0]
            if order[2] == 'invoiced':
                invoiced_amount += order[0]
        return [total_quotation, total_sales, invoiced_amount]
