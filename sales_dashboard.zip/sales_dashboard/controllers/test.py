[
    [
        {'id': 13, 'name': 'S00013', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 415.5},
        {'id': 12, 'name': 'S00012', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 556.0},
        {'id': 10, 'name': 'S00010', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 751.0},
        {'id': 8, 'name': 'S00008', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 462.0},
        {'id': 6, 'name': 'S00006', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Lumber Inc', 'total': 750.0},
        {'id': 9, 'name': 'S00009', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 654.0},
        {'id': 11, 'name': 'S00011', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1096.5},
        {'id': 5, 'name': 'S00005', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Deco Addict', 'total': 405.0}
    ]
]
[
    [
        {'id': 16, 'name': 'S00016', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1186.5},
        {'id': 14, 'name': 'S00014', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1582.0},
        {'id': 7, 'name': 'S00007', 'state': 'sale', 'invoice_status': 'to invoice', 'customer': 'Gemini Furniture', 'total': 1706.0},
        {'id': 4, 'name': 'S00004', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 2240.0},
        {'id': 3, 'name': 'S00003', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Ready Mat', 'total': 377.5},
        {'id': 15, 'name': 'S00015', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1541.5},
        {'id': 17, 'name': 'S00017', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 951.0},
        {'id': 20, 'name': 'S00020', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Joel Willis', 'total': 2947.5},
        {'id': 19, 'name': 'S00019', 'state': 'sent', 'invoice_status': 'no', 'customer': 'Joel Willis', 'total': 1740.0},
        {'id': 2, 'name': 'S00002', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Ready Mat', 'total': 2947.5},
        {'id': 1, 'name': 'S00001', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Deco Addict', 'total': 1740.0},
        {'id': 18, 'name': 'S00018', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 831.0}
    ],
    [
        {'id': 13, 'name': 'S00013', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 415.5},
        {'id': 12, 'name': 'S00012', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 556.0},
        {'id': 10, 'name': 'S00010', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 751.0},
        {'id': 8, 'name': 'S00008', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 462.0},
        {'id': 6, 'name': 'S00006', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Lumber Inc', 'total': 750.0},
        {'id': 9, 'name': 'S00009', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 654.0},
        {'id': 11, 'name': 'S00011', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1096.5},
        {'id': 5, 'name': 'S00005', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Deco Addict', 'total': 405.0}
    ]
]

{
    'total_quotation': 5470.0,
    'total_sales': 17670.5,
    'invoiced_amount': 0,
    'data': [{
        'quotations': 5065.0, 'sales': 12985.5, 'invoiced': 0,'name':"sales","id":10
        'data': [
            {'id': 16, 'name': 'S00016', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1186.5},
            {'id': 14, 'name': 'S00014', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1582.0},
            {'id': 7, 'name': 'S00007', 'state': 'sale', 'invoice_status': 'to invoice', 'customer': 'Gemini Furniture', 'total': 1706.0},
            {'id': 4, 'name': 'S00004', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 2240.0},
            {'id': 3, 'name': 'S00003', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Ready Mat', 'total': 377.5},
            {'id': 15, 'name': 'S00015', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1541.5},
            {'id': 17, 'name': 'S00017', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 951.0},
            {'id': 20, 'name': 'S00020', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Joel Willis', 'total': 2947.5},
            {'id': 19, 'name': 'S00019', 'state': 'sent', 'invoice_status': 'no', 'customer': 'Joel Willis', 'total': 1740.0},
            {'id': 2, 'name': 'S00002', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Ready Mat', 'total': 2947.5},
            {'id': 1, 'name': 'S00001', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Deco Addict', 'total': 1740.0},
            {'id': 18, 'name': 'S00018', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 831.0}
        ]}, {
        'quotations': 405.0, 'sales': 4685.0, 'invoiced': 0,
        'data': [
            {'id': 13, 'name': 'S00013', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 415.5},
            {'id': 12, 'name': 'S00012', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 556.0},
            {'id': 10, 'name': 'S00010', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 751.0},
            {'id': 8, 'name': 'S00008', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 462.0},
            {'id': 6, 'name': 'S00006', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Lumber Inc', 'total': 750.0},
            {'id': 9, 'name': 'S00009', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 654.0},
            {'id': 11, 'name': 'S00011', 'state': 'sale', 'invoice_status': 'no', 'customer': 'Gemini Furniture', 'total': 1096.5},
            {'id': 5, 'name': 'S00005', 'state': 'draft', 'invoice_status': 'no', 'customer': 'Deco Addict', 'total': 405.0}
        ]}
    ],
    'filter_id': 0}


